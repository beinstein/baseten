//---------------------------------------------------------------------------------------
//  $Id: OCMockRecorderTests.h 2 2004-08-24 17:00:05Z erik $
//  Copyright (c) 2004-2008 by Mulle Kybernetik. See License file for details.
//---------------------------------------------------------------------------------------

#import <SenTestingKit/SenTestingKit.h>


@interface OCMConstraintTests : SenTestCase 
{
	BOOL didCallCustomConstraint;
}

@end
