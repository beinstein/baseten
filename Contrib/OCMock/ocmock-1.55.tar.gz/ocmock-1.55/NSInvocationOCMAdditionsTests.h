//---------------------------------------------------------------------------------------
//  $Id: NSInvocationOCMAdditionsTests.h 21 2008-01-24 18:59:39Z erik $
//  Copyright (c) 2006-2008 by Mulle Kybernetik. See License file for details.
//---------------------------------------------------------------------------------------

#import <SenTestingKit/SenTestingKit.h>

@interface NSInvocationOCMAdditionsTests : SenTestCase 
{
}

@end
