//---------------------------------------------------------------------------------------
//  $Id: OCObserverMockObject.h $
//  Copyright (c) 2009 by Mulle Kybernetik. See License file for details.
//---------------------------------------------------------------------------------------

#import <SenTestingKit/SenTestingKit.h>


@interface OCObserverMockObjectTest : SenTestCase 
{
	NSNotificationCenter *center;
	
	id mock;
}

@end
