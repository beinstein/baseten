//---------------------------------------------------------------------------------------
//  $Id: $
//  Copyright (c) 2009 by Mulle Kybernetik. See License file for details.
//---------------------------------------------------------------------------------------

#import "OCMockRecorder.h"

@interface OCPartialMockRecorder : OCMockRecorder 
{
}

@end
